<template>
    <div class="risk">
        <h1>risk analysis</h1>
    </div>
</template>
<script>
export default {
    name: 'risk-analysis'
}
</script>