<template>
    <div class="prescription">
        <h1>Prescription</h1>
    </div>
</template>
<script>
export default {
    name: 'prescription'
}
</script>
<style lang="scss" scoped>
    
</style>