<template>
    <div class="patients">
        <h1>patients</h1>
    </div>
</template>
<script>
export default {
    name: 'patients'
}
</script>
<style lang="scss" scoped>
    
</style>