<template>
    <div class="prescription">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h3>Patient Info.</h3>
                    <h5 class="text-capitalize mb-0"></h5>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    name: 'make-prescription'
}
</script>
<style lang="scss" scoped>
    
</style>