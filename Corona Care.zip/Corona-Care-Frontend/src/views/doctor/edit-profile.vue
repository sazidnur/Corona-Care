<template>
    <div class="edit">
        <h1>Edit</h1>
    </div>
</template>
<script>
export default {
    name: 'edit-profile'
}
</script>
<style lang="scss" scoped>
    
</style>