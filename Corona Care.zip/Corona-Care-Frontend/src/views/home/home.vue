<template>
  <div class="home">
    <!-- Banner -->
    <div class="banner">
      <div class="container">
        <div class="row">
          <div class="col-12 col-lg-8 text-center text-lg-left banner-column">
            <h1 class="mb-4">
              Manage Your Health Care Online
              100%Cost Free
            </h1>
            <a href class="btn btn-lg shadow-none color-btn mb-2 mb-md-0">checkup now</a>
            <a href class="btn btn-lg shadow-none boder-btn ml-2">schedule</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Need section -->
    <div class="custom-need-section">
      <div class="container">
        <div class="row pb-5">
          <div class="col-12 text-center">
            <h1 class="mb-0">Care When You Need it!</h1>
          </div>
        </div>
        <div class="row">
          <div class="col-12 col-md-6 col-lg-3 mb-5 mb-lg-0 text-center">
            <i class="far fa-clock mb-3"></i>
            <h2>24/7 Available</h2>
          </div>
          <div class="col-12 col-md-6 col-lg-3 mb-5 mb-lg-0 text-center">
            <i class="far fa-calendar mb-3"></i>
            <h2>365 Days Service</h2>
          </div>
          <div class="col-12 col-md-6 col-lg-3 mb-5 mb-lg-0 text-center">
            <i class="fas fa-phone mb-3"></i>
            <h2>Offline Contacts Available</h2>
          </div>
          <div class="col-12 col-md-6 col-lg-3 mb-5 mb-lg-0 text-center">
            <i class="fas fa-check-double mb-3"></i>
            <h2>100% Cost FREE</h2>
          </div>
        </div>
      </div>
    </div>

    <!-- Approce section -->
    <div class="approce">
      <div class="flex-center flex-column text-center">
        <img src="../../assets/static/approch.svg" class="img-fluid mb-4" />
        <h1 class="mb-3">A new approach to healthcare</h1>
        <p>When it comes to health and wellbeing, we want to give you and your family peace of mind, whenever and wherever you need it.</p>
      </div>
    </div>

    <!-- manage section -->
    <div class="manage">
      <div class="container">
        <div class="row">
          <div class="col-12 col-lg-7 m-auto text-center">
            <h1 class="mb-4">The smart way to manage your health</h1>
            <p>Doctor Care Anywhere offers calm, reassuring support and advice and all the tools you need to take care of you and your family’s health, whenever and wherever you need it. Simple, safe, secure support. All at the touch of a button.</p>
          </div>
        </div>
      </div>
      <img src="../../assets/static/appmontage-2x.png" class="img-fluid mb-5" />
      <div class="container links-container">
        <div class="row py-2">
          <div class="col-12 col-sm-6 col-md-4 col-lg-2 text-center mb-0">
            <div class="card border-0 rounde-0">
              <div class="custom-content">
                <div class="custom-boder">
                  <div class="flex-center flex-column">
                    <i class="far fa-calendar-alt"></i>
                  </div>
                </div>
                <h6 class="mb-3">Appointments</h6>
              </div>
              <p>Video and phone GP appointments 8am – 10pm everyday</p>
            </div>
          </div>

          <div class="col-12 col-sm-6 col-md-4 col-lg-2 text-center mb-0">
            <div class="card border-0 rounde-0">
              <div class="custom-content">
                <div class="custom-boder">
                  <div class="flex-center flex-column">
                    <i class="fas fa-file-medical"></i>
                  </div>
                </div>
                <h6 class="mb-3">Prescriptions</h6>
              </div>
              <p>Video and phone GP appointments 8am – 10pm everyday</p>
            </div>
          </div>

          <div class="col-12 col-sm-6 col-md-4 col-lg-2 text-center mb-0">
            <div class="card border-0 rounde-0">
              <div class="custom-content">
                <div class="custom-boder">
                  <div class="flex-center flex-column">
                    <i class="fas fa-file-contract"></i>
                  </div>
                </div>
                <h6 class="mb-3">Referrals & fit notes</h6>
              </div>
              <p>Video and phone GP appointments 8am – 10pm everyday</p>
            </div>
          </div>

          <div class="col-12 col-sm-6 col-md-4 col-lg-2 text-center mb-0">
            <div class="card border-0 rounde-0">
              <div class="custom-content">
                <div class="custom-boder">
                  <div class="flex-center flex-column">
                    <i class="far fa-heart"></i>
                  </div>
                </div>
                <h6 class="mb-3">Health tracking</h6>
              </div>
              <p>Video and phone GP appointments 8am – 10pm everyday</p>
            </div>
          </div>

          <div class="col-12 col-sm-6 col-md-4 col-lg-2 text-center mb-0">
            <div class="card border-0 rounde-0">
              <div class="custom-content">
                <div class="custom-boder">
                  <div class="flex-center flex-column">
                    <i class="far fa-user"></i>
                  </div>
                </div>
                <h6 class="mb-3">Patient records</h6>
              </div>
              <p>Video and phone GP appointments 8am – 10pm everyday</p>
            </div>
          </div>

          <div class="col-12 col-sm-6 col-md-4 col-lg-2 text-center mb-0">
            <div class="card border-0 rounde-0">
              <div class="custom-content">
                <div class="custom-boder">
                  <div class="flex-center flex-column">
                    <i class="fas fa-globe-europe"></i>
                  </div>
                </div>
                <h6 class="mb-3">Travelling abroad</h6>
              </div>
              <p>Video and phone GP appointments 8am – 10pm everyday</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Happy paitient -->
    <div class="happy-paitients">
      <div class="custom-overlay">
        <div class="container">
          <div class="row">
            <div class="col-12 col-md-8 col-lg-6">
              <h1 class="mb-4">Happy doctors make happy patients</h1>
              <p
                class="mb-4"
              >That’s why we go out of our way to find the very best doctors we can. As a doctor founded company, all our GPs are chosen by doctors and specially trained in video consultation skills to give you the best quality medical care, whenever you need it.</p>
              <router-link to="/" class="btn shadow-none">
                Our Doctors
                <i class="fas fa-angle-right ml-2"></i>
              </router-link>
            </div>
          </div>
        </div>
      </div>
      <img src="../../assets/static/happy_patient.jpg" class="img-fluid" />
    </div>

    <!-- User Stories -->
    <div class="user-stories">
      <div class="container">
        <div class="row">
          <div class="col-12 col-lg-7 m-auto text-center pb-5">
            <h1 class="mb-4">User stories</h1>
            <p>All sorts of people use Doctor Care Anywhere for all sorts of reasons. Have a read of what some our users have to say.</p>
          </div>
        </div>
      </div>

      <div class="container-fluid">
        <div class="row">
          <div class="col-12 col-sm-6 col-lg-4 story-column mb-3 pr-sm-2 pr-lg-3">
            <div class="content bg-primary">
              <div class="flex-center flex-column text-center">
                <p>sean's story</p>
                <h3 class="mb-0">The app is amazing for monitoring my symptoms</h3>
              </div>
            </div>
            <div class="image-section">
              <img src="../../assets/static/story1.jpg" class="img-fluid" />
              <div class="custom-verlay"></div>
            </div>
          </div>

          <div class="col-12 col-sm-6 col-lg-4 story-column mb-3 pl-sm-2 px-lg-1">
            <div class="content bg-success">
              <div class="flex-center flex-column text-center">
                <p>sean's story</p>
                <h3 class="mb-0">The app is amazing for monitoring my symptoms</h3>
              </div>
            </div>
            <div class="image-section">
              <img src="../../assets/static/story2.jpg" class="img-fluid" />
              <div class="custom-verlay"></div>
            </div>
          </div>

          <div class="col-12 col-sm-6 col-lg-4 story-column mb-3 pr-sm-2 pr-lg-3">
            <div class="content bg-warning">
              <div class="flex-center flex-column text-center">
                <p>sean's story</p>
                <h3 class="mb-0">The app is amazing for monitoring my symptoms</h3>
              </div>
            </div>
            <div class="image-section">
              <img src="../../assets/static/story3.jpg" class="img-fluid" />
              <div class="custom-verlay"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "home",
  data() {
    return {};
  },
  mounted() {
    window.scrollTo(0, 0);
  }
};
</script>
<style lang="scss" scoped>
.home {
  background: url("../../assets/static/banner.jpg");
  background-size: cover;
  background-position: center;
  background-attachment: fixed;
  .banner {
    width: 100%;
    background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7));
    .banner-column {
      h1 {
        color: #ffffff;
        font-weight: 200;
        text-transform: uppercase;
        font-family: "Source Sans Pro", sans-serif;
      }
      .color-btn {
        color: #ffffff;
        font-weight: 200;
        text-transform: uppercase;
        font-size: 18px;
        border-radius: 25px;
        padding-left: 30px;
        padding-right: 30px;
        background: #2bae66;
        font-family: "Source Sans Pro", sans-serif;
        transition: 0.3s;
      }
      .color-btn:hover {
        background: #23804c;
      }
      .boder-btn {
        color: #ffffff;
        font-weight: 200;
        text-transform: uppercase;
        font-size: 18px;
        border-radius: 25px;
        padding-left: 30px;
        padding-right: 30px;
        border: 2px solid #2bae66;
        font-family: "Source Sans Pro", sans-serif;
        transition: 0.3s;
      }
      .boder-btn:hover {
        color: #ffffff;
        background: #23804c;
        border: 2px solid #23804c;
      }
    }
  }

  // custom-need-section
  .custom-need-section {
    padding-top: 80px;
    padding-bottom: 80px;
    background: #ffffff;
    h1 {
      font-weight: 200;
      color: #555;
      letter-spacing: 1px;
      text-transform: uppercase;
      font-family: "Source Sans Pro", sans-serif;
    }
    i {
      color: #2bae66;
      font-size: 32px;
    }
    h2 {
      font-size: 25px;
      font-weight: 200;
      color: #555;
      letter-spacing: 1px;
      text-transform: uppercase;
      font-family: "Source Sans Pro", sans-serif;
    }
  }

  //   Approce
  .approce {
    padding-top: 100px;
    padding-bottom: 100px;
    background: url("../../assets/static/dots-bg.png");
    background-size: cover;
    background-repeat: no-repeat;
    background-position: center;
    min-height: 450px;
    img {
      width: 320px;
      height: 250px;
    }
    h1 {
      font-weight: 200;
      color: #ffffff;
      font-size: 30px;
      letter-spacing: 1px;
      text-transform: uppercase;
      font-family: "Source Sans Pro", sans-serif;
    }
    p {
      font-weight: 200;
      color: #ffffff;
      font-size: 20px;
      margin-bottom: 0px;
      font-family: "Source Sans Pro", sans-serif;
    }
  }

  // Manage
  .manage {
    width: 100%;
    background: #ffffff;
    h1 {
      font-weight: 200;
      color: #555;
      letter-spacing: 1px;
      text-transform: uppercase;
      font-family: "Source Sans Pro", sans-serif;
    }
    p {
      font-weight: 200;
      color: #555;
      font-size: 20px;
      margin-bottom: 60px;
      font-family: "Source Sans Pro", sans-serif;
    }
  }

  // Custom need
  .links-container {
    padding-bottom: 20px;
    .card {
      .custom-content {
        color: #2bae66;
        cursor: pointer;
        .custom-boder {
          width: 45px;
          height: 45px;
          margin: auto;
          border: 2px solid #2bae66;
          border-radius: 25px;
          transition: 0.3s;
          i {
            font-size: 20px;
            padding: 5px;
            transition: 0.3s;
          }
        }
        h6 {
          cursor: pointer;
          font-weight: 600;
          font-size: 18px;
          font-family: "Source Sans Pro", sans-serif;
          transition: 0.3s;
        }
      }
      p {
        color: rgba(0, 0, 0, 0.945);
        font-size: 16px;
        line-height: 1.6rem;
      }
    }
    .card:hover .custom-content {
      color: #000;
    }
    .card:hover .custom-content .custom-boder {
      border: 2px solid #000;
    }
  }

  // Happy paitient
  .happy-paitients {
    width: 100%;
    overflow: hidden;
    .btn {
      color: #ffffff;
      font-weight: 600;
      background: #0050ff;
      border-radius: 25px;
      padding: 8px 25px;
      font-family: "Source Sans Pro", sans-serif;
    }
  }

  //   User stories
  .user-stories {
    padding-top: 70px;
    margin-bottom: 80px;
    background: #ffffff;
    h1 {
      font-weight: 200;
      font-family: "Source Sans Pro", sans-serif;
    }
    p {
      font-weight: 200;
      line-height: 1.8rem;
      font-family: "Source Sans Pro", sans-serif;
    }
    .story-column {
      cursor: pointer;
      .content {
        padding-left: 20px;
        padding-right: 20px;
        height: 250px;
        p {
          color: #ffffff;
          font-size: 18px;
          text-transform: uppercase;
        }
        h3 {
          color: #ffffff;
          font-weight: 200;
          font-family: "Source Sans Pro", sans-serif;
        }
      }
      .image-section {
        width: 100%;
        height: 220px;
        overflow: hidden;
        position: relative;
        img {
          width: 100%;
          min-height: 100%;
        }
        .custom-verlay {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: #ffffff4d;
          display: none;
        }
      }
    }
    .story-column:hover .image-section .custom-verlay {
      display: block;
    }
  }
}

@media (max-width: 768px) {
  .banner {
    height: 550px;
    padding-top: 150px;
    padding-left: 20px;
    padding-right: 20px;
    .banner-column {
      h1 {
        font-size: 30px;
      }
    }
  }
  .custom-need-section {
    h1 {
      font-size: 25px;
    }
  }
  .approce {
    p {
      width: 85%;
    }
  }
  .manage {
    padding-top: 70px;
    h1 {
      font-size: 25px;
    }
  }
  .happy-paitients {
    background: #ffffff;
    .custom-overlay {
      width: 100%;
      min-height: 100px;
      padding-top: 30px;
      padding-bottom: 30px;
      text-align: center;
      border-top: 1px solid #dfdfdf75;
      h1 {
        font-weight: 200;
        font-size: 25px;
        font-family: "Source Sans Pro", sans-serif;
      }
      p {
        font-weight: 200;
        font-size: 17px;
        line-height: 1.8rem;
        color: #000;
        font-family: "Source Sans Pro", sans-serif;
      }
    }
  }
  .user-stories {
    h1 {
      font-size: 25px;
    }
    p {
      font-size: 17px;
    }
  }
}
@media (min-width: 768px) {
  .banner {
    height: 550px;
    padding-top: 170px;
    .banner-column {
      h1 {
        font-size: 45px;
      }
    }
  }
  .custom-need-section {
    h1 {
      font-size: 30px;
    }
  }
  .approce {
    p {
      width: 700px;
    }
  }
  .manage {
    padding-top: 100px;
    h1 {
      font-size: 30px;
    }
  }
  .happy-paitients {
    height: 500px;
    position: relative;
    .custom-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      text-align: left;
      padding-top: 15%;
      h1 {
        font-weight: 200;
        font-size: 40px;
        color: #ffffff;
        font-family: "Source Sans Pro", sans-serif;
      }
      p {
        font-weight: 200;
        font-size: 20px;
        line-height: 1.8rem;
        color: #ffffff;
        font-family: "Source Sans Pro", sans-serif;
      }
    }
  }

  .user-stories {
    h1 {
      font-size: 40px;
    }
    p {
      font-size: 20px;
    }
  }
}
@media (min-width: 992px) {
  .happy-paitients {
    height: 100vh;
  }
}
</style>